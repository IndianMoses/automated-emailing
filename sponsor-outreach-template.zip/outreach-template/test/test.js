'use strict';
const assert = require('assert');
const { makeEnv } = require('./mock');

let passed = 0;
function ok(cond, msg) { assert.ok(cond, msg); passed++; }
function eq(a, b, msg) { assert.strictEqual(JSON.stringify(a), JSON.stringify(b), msg + ' (got ' + JSON.stringify(a) + ')'); passed++; }
function resp(code, obj, headers) { const t = JSON.stringify(obj); return { getResponseCode: () => code, getContentText: () => t, getHeaders: () => headers || {} }; }

const DRIVE_ID = '1AbCdEfGhIjKlMnOpQrStUvWxYz123456';
const DRIVE_LINK = 'https://drive.google.com/file/d/' + DRIVE_ID + '/view';
const HEADERS = ['Firm Name', 'Name of contact', 'Role', 'Email', 'Contacted by', 'Date Emailed', 'Status', 'Notes / Result'];
const SUBJECT = 'Partnership Enquiry 2026/27';
const htmlOf = raw => Buffer.from(raw.split('Content-Type: text/html; charset="UTF-8"\r\nContent-Transfer-Encoding: base64\r\n\r\n')[1]
  .split('\r\n--')[0].replace(/\r\n/g, ''), 'base64').toString('utf8');
function setting(ss, label, value) {
  const sh = ss.getSheetByName('Outreach Settings');
  for (let r = 2; r <= sh.getLastRow(); r++) {
    if (sh.getRange(r, 1).getValue() === label) { if (value !== undefined) sh.getRange(r, 2).setValue(value); return sh.getRange(r, 2).getValue(); }
  }
  throw new Error('no setting ' + label);
}
function dropdown(sheet, values) {
  sheet.getRange(2, 7, 999, 1).setDataValidation({ getCriteriaType: () => 'VALUE_IN_LIST', getCriteriaValues: () => [values, true] });
}

// ---------- fake free research services: Tavily web search and the Groq model ----------
const calls = { tavily: [], groq: [] };
const groqMode = {};
const TAVILY_KEYS = ['query', 'search_depth', 'max_results', 'include_answer', 'include_raw_content', 'topic', 'time_range'];
const page = (title, url, content, raw) => ({ title, url, content, raw_content: raw || null, score: 0.9 });
const answer = (json, extra) => resp(200, { choices: [{ message: { role: 'assistant', content: (extra || '') + '<json>' + JSON.stringify(json) + '</json>' }, finish_reason: 'stop' }] });
const slugOf = s => s.toLowerCase().replace(/[^a-z]/g, '');
// Firms researched in the end to end run: each has a published campus mailbox, some a named recruiter.
const GENERIC = { 'Jane Street': null, 'Two Sigma': { name: 'Alex Morgan', role: 'Campus Recruiter, EMEA' } };

function tavily(b) {
  const q = b.query;
  if (/^Omega Quant/.test(q)) return resp(432, { detail: { error: 'This request exceeds your plan\'s set usage limit.' } });
  if (/^Acme Capital campus recruitment email UK$/.test(q)) return resp(200, { results: [
    page('Campus programmes | Acme Capital', 'https://www.acmecapital.com/careers/campus', 'Acme Capital runs internships and graduate programmes in London.',
      'Questions about our campus events? Email campus-emea@acmecapital.com and the team will reply. Priya Shah, Graduate Recruitment Lead EMEA, p.shah@acmecapital.com. ' +
      'Press enquiries: media@acmecapital.com. Automated mail comes from noreply@acmecapital.com.'),
    page('Our sponsors | Another Trading Society', 'https://othersociety.org/sponsors', 'Our sponsors include Acme Capital.', 'Contact us at info@othersociety.org or careers@brightnetwork.co.uk')
  ] });
  if (/^Acme Capital graduate early careers/.test(q)) return resp(200, { results: [
    page('Sarah Khan, Head of Early Careers EMEA, Acme Capital | LinkedIn', 'https://uk.linkedin.com/in/sarahkhan', 'Sarah Khan. Head of Early Careers EMEA at Acme Capital. London.')
  ] });
  if (/^Acme Capital email format/.test(q)) return resp(200, { results: [
    page('Acme Capital Email Format | acmecapital.com', 'https://emailformats.example/acme', 'The most common Acme Capital email format is first.last@acmecapital.com (used 87% of the time).',
      'Examples: john.doe@acmecapital.com, jane.doe@acmecapital.com')
  ] });
  if (/^Acme Capital news 2026$/.test(q)) {
    ok(b.topic === 'news' && b.time_range === 'year', 'news search options');
    return resp(200, { results: [page('Acme Capital opens a machine learning lab in London', 'https://news.example/acme-lab',
      'Acme Capital has opened a London research lab applying machine learning to forecasting in electricity markets.')] });
  }
  if (/^Acme Capital acmecapital\.com technology/.test(q)) return resp(200, { results: [
    page('Engineering at Acme Capital', 'https://www.acmecapital.com/engineering', 'Acme Capital engineers build low latency trading systems in C++ and Python.')
  ] });
  if (/^Kappa Trading/.test(q)) return resp(200, { results: [
    page('Kappa Trading graduates', 'https://www.kappatrading.com/graduates', 'Graduate trading roles at Kappa Trading.', 'Write to careers@kappatrading.com.')
  ] });
  if (/^Zeta Partners/.test(q)) return resp(200, { results: [
    page('Zeta Partners careers', 'https://www.zetapartners.com/careers', 'Graduate roles at Zeta Partners in London.', 'Email grads@zetapartners.com for graduate questions.')
  ] });
  const firm = Object.keys(GENERIC).find(f => q.indexOf(f + ' ') === 0);
  if (firm) {
    const slug = slugOf(firm), person = GENERIC[firm];
    if (/campus recruitment email UK$/.test(q)) return resp(200, { results: [page('Campus recruiting | ' + firm, 'https://www.' + slug + '.com/careers',
      firm + ' hires interns and graduates in London.', 'For campus questions email campus@' + slug + '.com and the team will reply.')] });
    if (/graduate early careers/.test(q)) return resp(200, { results: person ? [page(person.name + ', ' + person.role + ', ' + firm + ' | LinkedIn',
      'https://uk.linkedin.com/in/' + slugOf(person.name), person.name + '. ' + person.role + ' at ' + firm + '. London.')] : [] });
    if (/email format/.test(q)) return resp(200, { results: [page(firm + ' Email Format', 'https://emailformats.example/' + slug,
      'The most common ' + firm + ' email format is first.last@' + slug + '.com.')] });
    if (/ news \d{4}$/.test(q)) return resp(200, { results: [page(firm + ' expands its London research team', 'https://news.example/' + slug,
      firm + ' has opened a London research lab applying machine learning to forecasting.')] });
    return resp(200, { results: [page('Engineering at ' + firm, 'https://www.' + slug + '.com/engineering', firm + ' engineers build low latency research infrastructure.')] });
  }
  return resp(200, { results: [] });
}

function groq(b) {
  const user = b.messages[1].content;
  const firm = user.match(/^Firm: (.+)$/m)[1].trim();
  const contacts = /research corporate contacts/.test(b.messages[0].content);
  ok(/Your Society, a student society at Your University/.test(b.messages[0].content), 'organisation settings reach the research prompts');
  calls.groq.push({ firm, contacts });
  const mode = groqMode[firm + (contacts ? ':contacts' : ':paragraph')];
  if (mode === 'daily') return resp(429, { error: { message: 'Rate limit reached on tokens per day (TPD)' } }, { 'retry-after': '3600' });
  if (mode === 'nojson-once') {
    delete groqMode[firm + ':contacts'];
    return resp(200, { choices: [{ message: { content: 'I think the careers mailbox is best.' }, finish_reason: 'stop' }] });
  }
  if (mode === 'minute-once') {
    delete groqMode[firm + ':paragraph'];
    return resp(429, { error: { message: 'Rate limit reached on tokens per minute (TPM)' } }, { 'Retry-After': '2' });
  }
  if (contacts) {
    eq(b.model, 'openai/gpt-oss-20b', 'contacts model');
    ok(user.length < 16000, 'contacts prompt fits the free per minute token limit (' + user.length + ' chars)');
    if (firm === 'Acme Capital') {
      ok(user.includes('campus-emea@acmecapital.com') && user.includes('p.shah@acmecapital.com'), 'emails found on the pages are given to the model');
      ok(!/^- (noreply|john\.doe|jane\.doe)@/m.test(user), 'no reply and example addresses not offered as contacts');
      return answer({ domain: 'acmecapital.com', email_format: '{first}.{last}@acmecapital.com', email_format_evidence: 'source [4]',
        contacts: [
          { name: 'EMEA Campus Team', role: 'Campus recruiting mailbox', email: 'campus-emea@acmecapital.com', email_type: 'role_mailbox', region: 'UK', confidence: 'high', source_url: 'https://www.acmecapital.com/careers/campus' },
          { name: 'Priya Shah', role: 'Graduate Recruitment Lead – EMEA', email: 'p.shah@acmecapital.com', email_type: 'published', region: 'EMEA', confidence: 'high', source_url: 'https://www.acmecapital.com/careers/campus' },
          { name: 'Sarah Khan', role: 'Head of Early Careers EMEA', email: 'skhan@acmecapital.com', email_type: 'pattern_guess', region: 'EMEA', confidence: 'high', source_url: 'https://uk.linkedin.com/in/sarahkhan' },
          { name: null, role: 'Media mailbox', email: 'media@acmecapital.com', email_type: 'role_mailbox', region: 'UK', confidence: 'high', source_url: 'https://www.acmecapital.com/careers/campus' },
          { name: 'Tom Invented', role: 'Campus Recruiter', email: 'tom.invented@acmecapital.com', email_type: 'pattern_guess', region: 'UK', confidence: 'medium', source_url: 'https://made.up/page' },
          { name: null, role: 'Recruiting', email: 'recruiting@acmecapital.com', email_type: 'published', region: 'UK', confidence: 'high', source_url: 'https://www.acmecapital.com/careers/campus' },
          { name: null, role: 'Careers service', email: 'careers@brightnetwork.co.uk', email_type: 'role_mailbox', region: 'UK', confidence: 'low', source_url: 'https://othersociety.org/sponsors' }
        ],
        recommended: ['recruiting@acmecapital.com', 'skhan@acmecapital.com', 'media@acmecapital.com'], notes: 'Campus mailbox is published — Sarah runs early careers.' }, 'Here is what I found. ');
    }
    if (firm === 'Kappa Trading') ok(!/did not end with valid JSON/.test(user) || calls.groq.filter(g => g.firm === firm).length === 2, 'second try says what was wrong');
    const slug = slugOf(firm), person = GENERIC[firm];
    if (firm in GENERIC) {
      const list = [
        { name: null, role: 'UK campus recruiting mailbox', email: 'campus@' + slug + '.com', email_type: 'role_mailbox', region: 'UK', confidence: 'high', source_url: 'https://www.' + slug + '.com/careers' },
        { name: null, role: 'Recruiting team', email: 'press@' + slug + '.com', email_type: 'published', region: 'UK', confidence: 'medium', source_url: 'https://www.' + slug + '.com/careers' }
      ];
      if (person) list.push({ name: person.name, role: person.role, email: person.name.replace(' ', '.') + '@' + slug + '.com', email_type: 'pattern_guess', region: 'UK', confidence: 'medium', source_url: 'https://uk.linkedin.com/in/' + slugOf(person.name) });
      return answer({ domain: 'https://www.' + slug + '.com/', email_format: '{first}.{last}@' + slug + '.com', email_format_evidence: 'email format page',
        contacts: list, recommended: [person ? list[2].email : list[0].email], notes: 'Mailbox is published.' }, 'Here is what I found. ');
    }
    const box = firm === 'Zeta Partners' ? 'grads@zetapartners.com' : 'careers@' + slug + '.com';
    return answer({ domain: slug + '.com', email_format: null, recommended: [box],
      contacts: [{ name: null, role: 'Graduate mailbox', email: box, email_type: 'role_mailbox', region: 'UK', confidence: 'high', source_url: 'https://www.' + slug + '.com/careers' }] });
  }
  eq(b.model, 'openai/gpt-oss-120b', 'paragraph model');
  ok(/^\[1\] /m.test(user), 'numbered sources in the paragraph prompt');
  const para = 'Given ' + firm + '’s strength in quantitative research — and technology, we believe there is a strong alignment with the interests of our members. ' +
    'We were particularly interested in ' + firm + '’s new London research lab, which applies machine learning to forecasting in electricity markets. ' +
    'This work closely aligns with our members’ interests in machine learning, statistics and systematic trading, and we would be very interested in exploring a partnership with ' + firm + '.';
  return answer({ paragraph: para, fact_used: 'London machine learning lab – 2026', sources: [1, 99, 'https://www.acmecapital.com/engineering', 'https://made.up/x'] });
}

function free(url, o) {
  if (url === 'https://api.groq.com/openai/v1/models') return resp(o.headers.Authorization === 'Bearer gsk_test' ? 200 : 401, { data: [] });
  if (url === 'https://api.tavily.com/search') {
    const b = JSON.parse(o.payload);
    ok(o.headers.Authorization === 'Bearer tvly-test', 'tavily auth');
    ok(Object.keys(b).every(k => TAVILY_KEYS.includes(k)), 'only documented Tavily options (' + Object.keys(b).join(',') + ')');
    ok(b.search_depth === 'basic' && b.max_results === 5, 'basic search, 5 results');
    calls.tavily.push(b);
    return tavily(b);
  }
  if (url === 'https://api.groq.com/openai/v1/chat/completions') {
    const b = JSON.parse(o.payload);
    ok(o.headers.Authorization === 'Bearer gsk_test', 'groq auth');
    ok(b.include_reasoning === false && /^(low|medium)$/.test(b.reasoning_effort) && b.max_completion_tokens > 0, 'gpt-oss options');
    return groq(b);
  }
  throw new Error('unexpected fetch ' + url);
}
const KEYS = { TAVILY_API_KEY: 'tvly-test', GROQ_API_KEY: 'gsk_test' };
const contactCalls = () => calls.groq.filter(g => g.contacts).length;

// ===================== 1. Pure helpers =====================
(function unitTests() {
  const env = makeEnv({ fetch: free });
  const c = env.call.bind(env);
  eq(c('extractEmails_', 'uSer@example.com/ http://site.com'), ['user@example.com'], 'email with link');
  eq(c('extractEmails_', '[uSer@example.com](mailto:uSer@example.com)'), ['user@example.com'], 'markdown mailto');
  eq(c('extractEmails_', 'Patlee@northgate.co.uk, see https://northgate.com/careers; TalentAcquisition@harbourgroup.com'), ['patlee@northgate.co.uk', 'talentacquisition@harbourgroup.com'], 'two emails');
  eq(c('extractEmails_', 'logo@2x.png  nothing here'), [], 'image name ignored');
  eq(c('extractEmails_', 'a.b@c.co.uk.'), ['a.b@c.co.uk'], 'trailing dot');
  const re = c('seasonRegex_', '26/27');
  ['Partnership Enquiry 2026/27', 'Re: Partnership 26/27', 'Sponsorship 2026-27', '2026/2027 partnership', 'x 2026 / 27']
    .forEach(s => ok(re.test(s), 'season match: ' + s));
  ['2025/26 partnership', 'ref 126/27', '26/270', 'Partnership Enquiry'].forEach(s => ok(!re.test(s), 'season no match: ' + s));
  eq(c('possessive_', 'Jane Street'), 'Jane Street’s', 'possessive');
  eq(c('possessive_', 'Citadel Securities'), 'Citadel Securities’', 'possessive s');
  eq(c('firstName_', 'Dr. Casey Morgan'), 'Casey', 'first name');
  eq(c('firstName_', 'University relations team'), 'University', 'first name plain');
  ok(c('tidyParagraph_', "Given X's — test - more").indexOf('—') === -1, 'dash removed');
  eq(c('noDash_', 'Campus Recruitment Manager – Quantitative Research'), 'Campus Recruitment Manager, Quantitative Research', 'dash in a role becomes a comma');
  eq(c('noDash_', 'data-driven work'), 'data-driven work', 'hyphenated words kept');
  eq(c('extractJson_', 'blah <json>{"a":1}</json> tail <json>{"b":2,}</json>'), { b: 2 }, 'json last block + trailing comma');
  eq(c('htmlToText_', '<p>A &amp; B</p><p>C<br />D</p>'), 'A & B\n\nC\nD', 'html to text');
  eq(c('normStatus_', 'Sent & Waiting'), 'sent and waiting', 'status norm');
  ok(c('isWaiting_', 'Sent and waiting'), 'waiting variant');
  ok(c('notSentYet_', 'Drafting') && c('notSentYet_', '') && c('notSentYet_', 'Not Contacted'), 'Drafting and blank count as not sent yet');
  ok(!c('notSentYet_', 'Sent & Waiting') && !c('notSentYet_', 'Sent Accepted') && !c('notSentYet_', 'Sent Rejected'), 'sent statuses do not');
  eq(c('greeting_', { contact: 'Priya Shah, Sarah Khan', emails: ['a@x.com', 'b@x.com'], firm: 'X' }, { greetByName: true }, false), 'Dear Sir/Madam', 'no first name when the email goes to two addresses');
  eq(c('greeting_', { contact: 'Priya Shah', emails: ['a@x.com'], firm: 'X' }, { greetByName: true }, false), 'Dear Priya', 'first name for one address');
  eq(c('driveId_', 'https://drive.google.com/file/d/1AbCdEfGhIjKlMnOpQrStUvWxYz123456/view?usp=sharing'), '1AbCdEfGhIjKlMnOpQrStUvWxYz123456', 'drive id');
  eq(c('colLetter_', 21), 'U', 'col letter');
  eq(c('hourText_', 9) + ' ' + c('hourText_', 12) + ' ' + c('hourText_', 15), '9am 12pm 3pm', 'hour text');

  // Dates (UK time; clocks went back on 25 Oct 2026, forward on 28 Mar 2027)
  const D = s => new env.ctx.Date(Date.parse(s));
  const iso = d => d.toISOString();
  env.at('2026-10-27T10:00:00Z'); // Tuesday
  eq(iso(c('nextDayAt_', D('2026-10-27T10:00:00Z'), 9)), '2026-10-28T09:00:00.000Z', 'tomorrow 9am GMT');
  eq(iso(c('nextMondayAt_', D('2026-10-27T10:00:00Z'), 9)), '2026-11-02T09:00:00.000Z', 'next Monday');
  eq(iso(c('nextMondayAt_', D('2026-11-02T08:30:00Z'), 9)), '2026-11-02T09:00:00.000Z', 'Monday before 9 is today');
  eq(iso(c('nextMondayAt_', D('2026-11-02T09:30:00Z'), 9)), '2026-11-09T09:00:00.000Z', 'Monday after 9 is next week');
  eq(iso(c('nextMondayAt_', D('2026-11-08T22:00:00Z'), 9)), '2026-11-09T09:00:00.000Z', 'Sunday night');
  eq(iso(c('nextDayAt_', D('2026-10-24T10:00:00Z'), 9)), '2026-10-25T09:00:00.000Z', 'day after clocks go back');
  eq(iso(c('nextDayAt_', D('2026-10-23T10:00:00Z'), 9)), '2026-10-24T08:00:00.000Z', 'BST 9am is 08:00 UTC');
  eq(iso(c('nextDayAt_', D('2027-03-27T10:00:00Z'), 9)), '2027-03-28T08:00:00.000Z', 'day clocks go forward');
  eq(iso(c('followUpDue_', D('2026-10-29T10:00:00Z'), 2, 9, true)), '2026-11-02T09:00:00.000Z', 'Thursday + 2 skips weekend');
  eq(iso(c('followUpDue_', D('2026-10-29T10:00:00Z'), 2, 9, false)), '2026-10-31T09:00:00.000Z', 'weekend allowed');
  eq(iso(c('followUpDue_', D('2026-10-26T23:30:00Z'), 7, 9, true)), '2026-11-02T09:00:00.000Z', 'late evening uses UK date');
  const s = { followUpHour: 9, skipWeekends: true };
  ok(c('inFollowUpWindow_', D('2026-11-02T09:05:00Z'), s), 'window Monday 9:05');
  ok(!c('inFollowUpWindow_', D('2026-11-02T10:05:00Z'), s), 'not 10:05');
  ok(!c('inFollowUpWindow_', D('2026-10-31T09:05:00Z'), s), 'not Saturday');
  ok(c('inFollowUpWindow_', D('2026-06-01T08:05:00Z'), s), 'BST window is 08 UTC');

  // MIME
  const raw = c('buildMime_', { fromName: 'Alex Taylor', fromEmail: 'alex.taylor@example.org', to: ['a@b.com'], subject: 'Re: Partnership Enquiry 2026/27',
    inReplyTo: '<x@y>', references: '<w@y> <x@y>', text: 'We’d be keen', html: '<p>We’d be keen</p>' });
  ok(/^From: "Alex Taylor" <alex.taylor@example.org>\r\n/.test(raw), 'mime from');
  ok(/\r\nIn-Reply-To: <x@y>\r\nReferences: <w@y> <x@y>\r\n/.test(raw), 'mime threading headers');
  eq(htmlOf(raw), '<p>We’d be keen</p>', 'mime html utf8 round trip');
  ok(/=\?UTF-8\?B\?/.test(c('encodeHeader_', 'Café')), 'encoded header');

  // thread analysis
  const ours = new Set(['oursociety@gmail.com', 'alex.taylor@example.org']);
  const settings = { seasonRe: re, seasonTag: '26/27' };
  const mk = (id, ms, labels, from, to, subject, extra, snippet) => ({ id, threadId: 't1', labelIds: labels, internalDate: String(ms), snippet: snippet || '',
    payload: { headers: [{ name: 'From', value: from }, { name: 'To', value: to }, { name: 'Subject', value: subject }, { name: 'Message-ID', value: '<' + id + '@m>' }].concat(extra || []) } });
  const sub = SUBJECT;
  let a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], '"Alex Taylor" <alex.taylor@example.org>', 'campus@firm.com', sub),
    mk('m2', 2000, ['INBOX'], 'Out <campus@firm.com>', 'alex.taylor@example.org', 'Automatic reply: ' + sub),
    mk('m3', 3000, ['SENT'], '"Alex Taylor" <alex.taylor@example.org>', 'campus@firm.com', 'Re: ' + sub),
    mk('m4', 3500, ['DRAFT'], '"Alex Taylor" <alex.taylor@example.org>', 'campus@firm.com', 'Re: ' + sub)
  ] }, ['campus@firm.com'], ours, settings);
  eq(a.followUpsSent, 1, 'manual follow up counted, draft ignored');
  eq(a.autoReplies.length, 1, 'auto reply');
  eq(a.replies.length, 0, 'no real reply');
  eq(a.sendTo, ['campus@firm.com'], 'send to');
  eq(a.inReplyTo, '<m3@m>', 'in reply to last outbound');
  eq(a.references, '<m1@m> <m2@m> <m3@m>', 'references chain');
  a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', 'campus@firm.com', sub),
    mk('m2', 2000, ['INBOX'], 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', 'alex.taylor@example.org', 'Delivery Status Notification (Failure)')
  ] }, ['campus@firm.com'], ours, settings);
  ok(a.bounces.length === 1 && a.fullBounce, 'bounce detected and stops the row');
  // Two recipients: a bounce naming one of them only removes that one.
  const two = 'campus@firm.com, alex.morgan@firm.com';
  a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', two, sub),
    mk('m2', 2000, ['INBOX'], 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', 'alex.taylor@example.org', 'Delivery Status Notification (Failure)',
      [{ name: 'X-Failed-Recipients', value: 'alex.morgan@firm.com' }])
  ] }, ['campus@firm.com', 'alex.morgan@firm.com'], ours, settings);
  ok(!a.fullBounce && a.bounced.length === 1 && a.bounced[0].email === 'alex.morgan@firm.com', 'partial bounce from the failed recipients header');
  eq(a.sendTo, ['campus@firm.com'], 'follow ups only to the address that worked');
  a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', two, sub),
    mk('m2', 2000, ['INBOX'], 'postmaster@outlook.com', 'alex.taylor@example.org', 'Undeliverable: ' + sub, [], 'Your message to alex.morgan@firm.com couldn\'t be delivered.')
  ] }, ['campus@firm.com', 'alex.morgan@firm.com'], ours, settings);
  ok(!a.fullBounce && a.sendTo.join() === 'campus@firm.com', 'partial bounce read from the bounce text');
  a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', two, sub),
    mk('m2', 2000, ['INBOX'], 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', 'x', 'Delivery Status Notification (Failure)', [{ name: 'X-Failed-Recipients', value: 'alex.morgan@firm.com' }]),
    mk('m3', 2500, ['INBOX'], 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', 'x', 'Delivery Status Notification (Failure)', [{ name: 'X-Failed-Recipients', value: 'campus@firm.com' }])
  ] }, ['campus@firm.com', 'alex.morgan@firm.com'], ours, settings);
  ok(a.fullBounce, 'every address bounced stops the row');
  a = c('analyzeThread_', { id: 't1', messages: [
    mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', 'campus@firm.com', sub),
    mk('m2', 2000, ['INBOX'], 'Jo <jo@firm.com>', 'alex.taylor@example.org', 'RE: ' + sub, [{ name: 'Auto-Submitted', value: 'no' }])
  ] }, ['campus@firm.com'], ours, settings);
  eq(a.replies.length, 1, 'reply from colleague counts');
  a = c('analyzeThread_', { id: 't1', messages: [mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', 'other@firm.com', sub)] }, ['campus@firm.com'], ours, settings);
  ok(a.problems.length === 1 && /not in column D/.test(a.problems[0]), 'recipient mismatch blocks follow ups');
  a = c('analyzeThread_', { id: 't1', messages: [mk('m1', 1000, ['SENT'], 'alex.taylor@example.org', 'campus@firm.com', 'Hello there')] }, ['campus@firm.com'], ours, settings);
  ok(a.problems.some(p => /26\/27/.test(p)), 'subject without season blocks follow ups');

  // research helpers
  eq(c('formatTemplate_', '{first}.{last}@acme.com'), '{first}.{last}', 'format braces');
  eq(c('formatTemplate_', 'first.last'), '{first}.{last}', 'format words');
  eq(c('formatTemplate_', 'FirstName.LastName@acme.com'), '{first}.{last}', 'format name words');
  eq(c('formatTemplate_', 'flast'), '{f}{last}', 'format flast');
  eq(c('formatTemplate_', '{f}{last}'), '{f}{last}', 'format hunter style');
  eq(c('formatTemplate_', 'f.last'), '{f}.{last}', 'format f.last');
  eq(c('formatTemplate_', 'firstl'), '{first}{l}', 'format firstl');
  eq(c('formatTemplate_', '[first]_[last]'), '{first}_{last}', 'format square brackets');
  eq(c('formatTemplate_', 'jsmith@acme.com'), '', 'an example address is not a format');
  eq(c('formatTemplate_', 'unknown'), '', 'unknown format');
  eq(c('formatTemplate_', null), '', 'no format');
  eq(c('guessEmail_', '{first}.{last}', 'Siobhán O\'Brien-Lee', 'acme.com'), 'siobhan.obrienlee@acme.com', 'guess strips accents and punctuation');
  eq(c('guessEmail_', '{f}{last}', 'Dr. Sarah Khan', 'acme.com'), 'skhan@acme.com', 'guess with title');
  eq(c('guessEmail_', '{first}.{last}', 'Priya', 'acme.com'), '', 'no guess from one name');
  ok(c('nameInText_', 'Sarah Khan', 'head of early careers sarah khan, london'), 'name found');
  ok(!c('nameInText_', 'Sam Lee', 'samuel leeds'), 'name needs whole words');
  ok(c('firmAddress_', 'campus@janestreet.com', 'Jane Street', ''), 'firm address by name');
  ok(c('firmAddress_', 'x@careers.mlp.com', 'Millennium', 'mlp.com'), 'firm address by domain');
  ok(!c('firmAddress_', 'x@notmlp.com', 'Millennium', 'mlp.com'), 'look alike domain rejected');
  ok(!c('firmAddress_', 'careers@brightnetwork.co.uk', 'Acme Capital', 'acmecapital.com'), 'third party rejected');
  ok(c('junkEmail_', 'noreply@acme.com') && c('junkEmail_', 'john.doe@acme.com') && c('junkEmail_', 'first.last@acme.com'), 'junk addresses');
  ok(!c('junkEmail_', 'campus@acme.com'), 'real mailbox kept');
  ok(c('teamName_', 'EMEA Campus Team') && !c('teamName_', 'Priya Shah'), 'team names are not people');
  const ctxs = c('emailContexts_', 'Email campus@acme.com or noreply@acme.com. Again: Campus@Acme.com.');
  eq(ctxs.map(x => x.email), ['campus@acme.com'], 'page emails deduplicated, junk skipped');
  ok(/Email campus@acme\.com or/.test(ctxs[0].context), 'context kept');

  // Picking addresses: every relevant one, published first, press and sales never, limited by the setting.
  const ev = {
    sources: [{ n: 1, title: 'Northgate contact', url: 'https://www.northgate.com/contact', content: 'Contact Northgate' }],
    allEmails: {
      'recruitment@northgate.co.uk': { url: 'https://www.northgate.com/contact' }, 'media@northgate.com': { url: 'https://www.northgate.com/contact' },
      'sales@northgate.com': { url: 'https://www.northgate.com/contact' }
    },
    text: 'northgate contact recruitment@northgate.co.uk media@northgate.com robin ashford, campus recruitment manager at northgate. ' +
      'the most common northgate email format is first.last@northgate.com'
  };
  const model = () => ({ domain: 'northgate.com', format: '{first}.{last}@northgate.com', evidence: '', recommended: ['recruitment@northgate.co.uk'], notes: '', hunterPattern: '',
    contacts: [
      { name: 'Robin Ashford', role: 'Campus Recruitment Manager, Quantitative Research', email: 'robin.ashford@northgate.com', type: 'pattern_guess', region: 'UK', confidence: 'medium', source: '' },
      { name: '', role: 'Recruitment mailbox', email: 'recruitment@northgate.co.uk', type: 'role_mailbox', region: 'UK', confidence: 'high', source: '' },
      { name: '', role: 'Media mailbox', email: 'media@northgate.com', type: 'role_mailbox', region: 'UK', confidence: 'high', source: '' },
      { name: '', role: 'Sales desk', email: 'sales@northgate.com', type: 'role_mailbox', region: 'UK', confidence: 'high', source: '' }
    ] });
  eq(c('verifyContacts_', model(), ev, null, 'Northgate', 3).recommended, ['recruitment@northgate.co.uk', 'robin.ashford@northgate.com'],
    'both relevant addresses picked (the Northgate case), media and sales left out');
  eq(c('verifyContacts_', model(), ev, null, 'Northgate', 1).recommended, ['recruitment@northgate.co.uk'], 'the setting limits how many');
})();

// ===================== 2. End to end on a copy of the tracker =====================
const env = makeEnv({ fetch: free, driveId: DRIVE_ID, start: '2026-10-27T10:00:00Z' });
const { ss, mail } = env;
const tracker = env.makeSheet('Sponsorship Tracker', [
  HEADERS,
  ['Northgate', '', '', 'Patlee@northgate.co.uk', 'Sam Jones', '', 'Sent Accepted', ''],
  ['Riverbend', 'Casey Morgan', 'University Talent Acquisition Specialist - Trading & Research', 'cmorgan@riverbend.co.uk', 'Sam Jones', 'Sent 24/08/26', 'Sent & Waiting', 'Doesn\'t work there anymore'],
  ['Harbour Group', '', 'Talent Acquistion', 'TalentAcquisition@harbourgroup.com', 'Alex Taylor', 'Sent 24/08/26, F', 'Sent & Waiting', 'Jordan']
]);
// their existing Status dropdown, without Replied or Bounced
dropdown(tracker, ['Sent Accepted', 'Sent & Waiting', 'Sent Rejected']);
ss._sheets.push(tracker);
ss._active = tracker;
const COL = env.ctx.__COL;
const cell = (r, c) => tracker.getRange(r, c).getValue();

// Hand sent emails that already exist in Gmail (Riverbend from Sam on 24/08/26, Northgate earlier)
env.addMessage({ labels: ['SENT'], date: Date.parse('2026-08-24T09:12:00Z'), from: '"Sam Jones" <sam.jones@example.org>', to: 'cmorgan@riverbend.co.uk', subject: SUBJECT });
env.addMessage({ labels: ['SENT'], date: Date.parse('2026-08-20T09:12:00Z'), from: 'Your Society <oursociety@gmail.com>', to: 'patlee@northgate.co.uk', subject: 'Partnership x Northgate 26/27' });
// An old 25/26 email to Harbour Group must not count
env.addMessage({ labels: ['SENT'], date: Date.parse('2025-09-01T09:00:00Z'), from: 'alex.taylor@example.org', to: 'talentacquisition@harbourgroup.com', subject: 'Partnership Enquiry 2025/26' });

// --- install
env.run('setupOutreach');
eq(tracker.getRange(1, 9, 1, 13).getValues()[0], ['Draft email?', 'Send', 'Follow ups on', 'Days between follow ups', 'Note for next follow up', 'Next step', 'Activity log', 'Personalised paragraph', 'Research notes', 'Follow ups sent', 'Thread ID', 'Draft ID', 'Next action at'], 'headers');
eq(env.triggers.map(t => t.fn).sort(), ['dailySync', 'dispatcher', 'handleEdit'], 'triggers');
ok(ss.getSheetByName('Outreach Settings') && ss.getSheetByName('Outreach Senders'), 'settings and senders sheets');
eq(env.props.get('OWNER_EMAIL'), 'oursociety@gmail.com', 'owner');
ok(env.log.alerts.some(a => /Add Replied and Bounced/.test(a)), 'setup mentions missing statuses');
ok(env.log.alerts.some(a => /Set Tavily key/.test(a) && /Set Groq key/.test(a)), 'setup lists the free keys to add');
const labels = ss.getSheetByName('Outreach Settings').getRange(2, 1, 30, 1).getValues().map(r => r[0]).filter(x => x);
ok(!labels.includes('Claude model') && !labels.includes('Research engine'), 'no Claude settings');
ok(labels.includes('Most email addresses per firm'), 'address limit setting');
env.run('setupOutreach'); // repair run must not duplicate triggers or overwrite settings
eq(env.triggers.length, 3, 'no duplicate triggers');
setting(ss, 'Prospectus (Google Drive link)', DRIVE_LINK);
Object.keys(KEYS).forEach(k => env.props.set(k, KEYS[k]));

// --- typing a firm queues research; dispatcher researches it
tracker.getRange(5, 1).setValue('Jane Street');
env.edit(tracker, 5, 1);
eq(cell(5, COL.RESEARCH), 'Queued for research', 'queued');
// old rows are not researched (already contacted)
eq(cell(3, COL.RESEARCH), '', 'contacted rows not queued');
env.at('2026-10-27T10:10:00Z');
env.run('dispatcher');
eq(cell(5, COL.EMAIL), 'campus@janestreet.com', 'recommended email filled');
eq(cell(5, COL.CONTACT), '', 'mailbox has no person name');
ok(/^Given Jane Street’s strength in quantitative research, and technology/.test(cell(5, COL.PARAGRAPH)), 'paragraph tidied (dash removed, curly apostrophe)');
ok(/^Researched 27\/10\/26\nDomain: janestreet\.com \| Email format: \{first\}\.\{last\}@janestreet\.com/.test(cell(5, COL.RESEARCH)), 'research notes');
ok(/• campus@janestreet\.com \| UK campus recruiting mailbox \| role_mailbox/.test(cell(5, COL.RESEARCH)), 'contacts listed');
ok(/Not used [^\n]*press@janestreet\.com/.test(cell(5, COL.RESEARCH)), 'address the model made up is not used');
ok(/Paragraph based on: London machine learning lab, 2026/.test(cell(5, COL.RESEARCH)), 'dash removed from the notes');
ok(/Check email and paragraph/.test(cell(5, COL.NEXT)), 'next step after research');
eq(contactCalls(), 1, 'one contact search');

// sync at 7am links Riverbend's hand sent email; Northgate is closed so it is skipped
env.at('2026-10-28T07:20:00Z');
env.run('dailySync');
ok(cell(3, COL.THREAD_ID), 'Riverbend thread linked');
ok(/Sent 24\/08\/26 \(found in Gmail and linked\)/.test(cell(3, COL.LOG)), 'Riverbend log');
eq(cell(3, COL.DATE_EMAILED), 'Sent 24/08/26', 'Riverbend date kept');
ok(/Follow ups off/.test(cell(3, COL.NEXT)), 'Riverbend follow ups stay off until ticked');
eq(cell(2, COL.THREAD_ID), '', 'Northgate (accepted) untouched');
eq(cell(4, COL.THREAD_ID), '', 'Harbour Group 25/26 email ignored');

// --- drafting: no sender yet -> refused, then Alex -> draft
env.edit(tracker, 5, COL.DRAFT, 'Yes');
eq(cell(5, COL.DRAFT), '', 'draft request cleared on error');
ok(/Not drafted: choose who is sending/.test(cell(5, COL.NEXT)), 'needs sender');
tracker.getRange(5, COL.SENDER).setValue('Alex Taylor');
env.edit(tracker, 5, COL.DRAFT, 'Yes');
eq(cell(5, COL.DRAFT), 'Drafted', 'drafted');
eq(cell(5, COL.STATUS), '', 'status untouched when the dropdown has no Drafting');
const draftId = cell(5, COL.DRAFT_ID);
ok(/^r-/.test(draftId), 'draft id stored');
eq(cell(5, COL.FU_ON), true, 'follow ups switched on');
eq(cell(5, COL.FU_DAYS), 7, 'default days');
const dmsg = mail.messages.get(mail.drafts.get(draftId));
eq(dmsg.headers.From, '"Alex Taylor" <alex.taylor@example.org>', 'draft from alias');
eq(dmsg.headers.Subject, SUBJECT, 'subject');
eq(dmsg.headers.To, 'campus@janestreet.com', 'draft to');
eq(dmsg.attachments.length, 1, 'prospectus attached');
ok(dmsg.body.indexOf('Depending on Jane Street’s objectives') !== -1, 'firm possessive filled');
ok(dmsg.body.indexOf('to discuss how Jane Street could work with Your Society?') !== -1, 'firm and organisation names filled');
ok(dmsg.body.indexOf('<p>Dear Sir/Madam,</p>') !== -1, 'greeting');
ok(dmsg.body.indexOf('on behalf of <strong>Your Society</strong>, a student society at Your University, to ask whether Jane Street') !== -1, 'organisation settings used');
ok(dmsg.body.indexOf('strong interest in quantitative research, data science, software engineering and finance.') !== -1, 'member interests used');
ok(dmsg.body.indexOf('our 2026/27 sponsorship prospectus') !== -1, 'academic year');
ok(dmsg.body.indexOf('Head of Partnerships<br />\nYour Society') !== -1, 'title and organisation line in signature');
ok(dmsg.body.indexOf('mailto:alex.taylor@example.org') !== -1, 'sender email in signature');
ok(dmsg.body.indexOf('{{') === -1, 'no placeholders left');

// --- schedule for 9am Monday, then cancel, then reschedule
env.at('2026-10-28T11:00:00Z'); // Wednesday
env.edit(tracker, 5, COL.SEND, '9am Monday');
eq(cell(5, COL.SEND), '', 'send cell reset');
eq(cell(5, COL.NEXT_AT), '2026-11-02T09:00:00.000Z', 'scheduled Monday 9am');
ok(/First email scheduled for Mon 02\/11\/26 09:00/.test(cell(5, COL.NEXT)), 'schedule text');
env.edit(tracker, 5, COL.SEND, 'Cancel scheduled send');
eq(cell(5, COL.NEXT_AT), '', 'cancelled');
env.edit(tracker, 5, COL.SEND, '9am Monday');
env.at('2026-11-02T08:55:00Z');
env.run('dispatcher');
eq(env.log.sends.length, 0, 'not sent before 9');
env.at('2026-11-02T09:04:00Z');
env.run('dispatcher');
eq(env.log.sends.length, 1, 'sent at 9');
const threadJS = cell(5, COL.THREAD_ID);
ok(threadJS && !cell(5, COL.DRAFT_ID), 'thread stored, draft id cleared');
eq(cell(5, COL.STATUS), 'Sent & Waiting', 'status waiting');
eq(cell(5, COL.DATE_EMAILED), 'Sent 02/11/26', 'date emailed');
eq(cell(5, COL.NEXT_AT), '2026-11-09T09:00:00.000Z', 'follow up 1 due in 7 days');
ok(/Follow up 1 of 2 due Mon 09\/11\/26 09:00/.test(cell(5, COL.NEXT)), 'follow up text');
env.run('dispatcher');
eq(env.log.sends.length, 1, 'no double send on next run');

// --- follow up 1 with a note, at 9am a week later
tracker.getRange(5, COL.FU_NOTE).setValue('We are also running a trading competition on 20 November.');
env.at('2026-11-09T09:03:00Z');
env.run('dispatcher');
eq(env.log.sends.length, 2, 'follow up sent');
let fu = env.log.sends[1];
eq(fu.kind, 'followup', 'follow up kind');
eq(fu.threadId, threadJS, 'same thread');
eq(fu.to, 'campus@janestreet.com', 'follow up to');
eq(fu.subject, 'Re: ' + SUBJECT, 'follow up subject');
ok(fu.inReplyTo === '<sent-' + mail.threads.get(threadJS).ids[0] + '@mail.gmail.com>', 'in reply to original');
const fuHtml = htmlOf(fu.raw);
ok(fuHtml.indexOf('<p>Dear Jane Street Team</p>') !== -1, 'follow up greeting');
ok(fuHtml.indexOf('partnership between Jane Street and Your Society for the 2026/27 academic year') !== -1, 'follow up firm');
ok(/trading competition on 20 November\.<\/p>\s*<p>Kind regards,<\/p>/.test(fuHtml), 'note before signature');
ok(fuHtml.indexOf('Alex Taylor<br />Head of Partnerships<br />Your Society') !== -1, 'follow up signature');
eq(cell(5, COL.FU_COUNT), 1, 'count 1');
eq(cell(5, COL.FU_NOTE), '', 'note cleared');
ok(/^Followed up 09\/11\/26 \(follow up 1, Alex Taylor to campus@janestreet.com, note: We are also/.test(cell(5, COL.LOG)), 'log follow up');
eq(cell(5, COL.NEXT_AT), '2026-11-16T09:00:00.000Z', 'follow up 2 due');
env.at('2026-11-09T09:13:00Z');
env.run('dispatcher');
eq(env.log.sends.length, 2, 'no repeat in same window');

// --- a hand sent follow up resets the clock and counts towards the maximum
env.addMessage({ threadId: threadJS, labels: ['SENT'], date: Date.parse('2026-11-12T15:00:00Z'), from: 'alex.taylor@example.org', to: 'campus@janestreet.com', subject: 'Re: ' + SUBJECT });
env.at('2026-11-13T07:30:00Z');
env.run('dailySync');
eq(cell(5, COL.FU_COUNT), 2, 'manual follow up counted');
ok(/Followed up 12\/11\/26 \(sent by hand, found in Gmail\)/.test(cell(5, COL.LOG)), 'manual follow up logged');
ok(/Follow ups finished \(2 sent\)/.test(cell(5, COL.NEXT)), 'max reached');
eq(cell(5, COL.NEXT_AT), '', 'nothing due');

// --- raising the maximum to 3 schedules from the hand sent date; a reply stops it
setting(ss, 'Maximum follow ups', '3');
env.edit(tracker, 5, COL.FU_DAYS, 7);
eq(cell(5, COL.NEXT_AT), '2026-11-19T09:00:00.000Z', 'next due from hand sent follow up');
env.addMessage({ threadId: threadJS, labels: ['INBOX'], date: Date.parse('2026-11-17T10:00:00Z'), from: 'Sam Lee <slee@janestreet.com>', to: 'alex.taylor@example.org', subject: 'RE: ' + SUBJECT });
env.at('2026-11-19T09:02:00Z');
env.run('dispatcher');
eq(env.log.sends.length, 2, 'no follow up after reply');
ok(/Reply received 17\/11\/26 from slee@janestreet.com/.test(cell(5, COL.LOG)), 'reply logged');
eq(cell(5, COL.STATUS), 'Sent & Waiting', 'status not changed when Replied is not in their dropdown');
ok(/Reply received 17\/11\/26: follow ups stopped/.test(cell(5, COL.NEXT)), 'next step says stopped');

// --- duplicate protection: a new Northgate row (already emailed by hand in August)
tracker.getRange(6, 1, 1, 5).setValues([['Northgate', '', '', 'PatLee@northgate.co.uk', 'Jordan Lee']]);
tracker.getRange(6, COL.PARAGRAPH).setValue('Given Northgate’s strength in market making, we believe there is a strong alignment with the interests of our members. We were particularly interested in its work. This aligns with our members and we would be very interested in exploring a partnership with Northgate.');
env.edit(tracker, 6, COL.DRAFT, 'Yes');
eq(mail.drafts.size, 0, 'no draft for an address already emailed this season');
ok(/Not drafted 19\/11\/26: patlee@northgate.co.uk was already emailed on 20\/08\/26/.test(cell(6, COL.LOG)), 'duplicate logged');
ok(cell(6, COL.THREAD_ID), 'earlier thread linked to the new row');

// --- two addresses found: both go in the Email column; safety checks before sending
tracker.getRange(7, 1, 1, 5).setValues([['Two Sigma', '', '', '', 'Sam Jones']]);
env.edit(tracker, 7, 1);
env.at('2026-11-19T09:20:00Z');
env.run('dispatcher');
eq(cell(7, COL.EMAIL), 'campus@twosigma.com, alex.morgan@twosigma.com', 'every relevant address in the Email column, published first');
eq(cell(7, COL.CONTACT), 'Alex Morgan', 'contact name filled');
eq(cell(7, COL.ROLE), 'Campus Recruiter, EMEA', 'role filled');
env.edit(tracker, 7, COL.DRAFT, 'Yes');
const draft2 = cell(7, COL.DRAFT_ID);
ok(draft2, 'Two Sigma drafted');
eq(mail.messages.get(mail.drafts.get(draft2)).headers.To, 'campus@twosigma.com,alex.morgan@twosigma.com', 'draft goes to both addresses');
env.edit(tracker, 7, COL.EMAIL, 'campus@twosigma.com');
ok(/Email or Contacted by changed/.test(cell(7, COL.NEXT)), 'warned about changed email');
env.edit(tracker, 7, COL.SEND, 'Send now');
eq(env.log.sends.length, 2, 'blocked: draft recipients differ from column D');
ok(/Not sent 19\/11\/26: the draft goes to campus@twosigma.com, alex.morgan@twosigma.com but column D has campus@twosigma.com/.test(cell(7, COL.LOG)), 'mismatch logged');
tracker.getRange(7, COL.EMAIL).setValue('campus@twosigma.com, alex.morgan@twosigma.com');
env.edit(tracker, 7, COL.DRAFT, 'Yes');
eq(cell(7, COL.DRAFT_ID), draft2, 'draft updated in place, same id');
// someone sends the draft straight from Gmail instead of using the sheet
env.ctx.GmailApp.getDraft(draft2).send();
const sendsBefore = env.log.sends.length;
env.edit(tracker, 7, COL.SEND, 'Send now');
eq(env.log.sends.length, sendsBefore, 'not sent twice');
ok(cell(7, COL.THREAD_ID), 'thread adopted after hand send');
ok(/the draft was already sent from Gmail/.test(cell(7, COL.LOG)), 'explained');
eq(cell(7, COL.STATUS), 'Sent & Waiting', 'status set when the email sent from Gmail is linked');

// --- one of the two addresses bounces: follow ups carry on to the other
const t2s = cell(7, COL.THREAD_ID);
env.addMessage({ threadId: t2s, labels: ['INBOX'], date: Date.parse('2026-11-19T09:25:00Z'), from: 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', to: 'sam.jones@example.org',
  subject: 'Delivery Status Notification (Failure)', headers: { 'X-Failed-Recipients': 'alex.morgan@twosigma.com' },
  body: 'Address not found. Your message wasn\'t delivered to alex.morgan@twosigma.com because the address couldn\'t be found.' });
env.at('2026-11-20T07:30:00Z');
env.run('dailySync');
ok(/Bounce back detected 19\/11\/26 for alex\.morgan@twosigma\.com \(the other addresses still get follow ups\)/.test(cell(7, COL.LOG)), 'partial bounce logged');
ok(/^Follow up 1 of 3 due Thu 26\/11\/26 09:00/.test(cell(7, COL.NEXT)), 'follow ups continue for the address that worked');
// --- then a bounce back that names nobody: follow ups stop
env.addMessage({ threadId: t2s, labels: ['INBOX'], date: Date.parse('2026-11-20T10:00:00Z'), from: 'Mail Delivery Subsystem <mailer-daemon@googlemail.com>', to: 'sam.jones@example.org', subject: 'Delivery Status Notification (Failure)' });
env.at('2026-11-21T07:30:00Z');
env.run('dailySync');
ok(/^Bounce back detected 20\/11\/26$/m.test(cell(7, COL.LOG)), 'bounce logged');
ok(/^Bounced/.test(cell(7, COL.NEXT)), 'bounce next step');

// --- status change pauses follow ups (Riverbend: tick follow ups, then reject)
env.edit(tracker, 3, COL.FU_ON, true);
ok(/Follow up 1 of 3 due/.test(cell(3, COL.NEXT)), 'Riverbend follow up scheduled once ticked');
ok(Date.parse(cell(3, COL.NEXT_AT)) < Date.now(), 'overdue (sent in August)');
env.edit(tracker, 3, COL.STATUS, 'Sent Rejected');
ok(/Follow ups paused: Status is Sent Rejected/.test(cell(3, COL.NEXT)), 'paused by status');
env.at('2026-11-23T09:05:00Z');
const n1 = env.log.sends.length;
env.run('dispatcher');
eq(env.log.sends.length, n1, 'no follow up for rejected');
env.edit(tracker, 3, COL.STATUS, 'Sent & Waiting');
env.run('dispatcher');
eq(env.log.sends.length, n1 + 1, 'overdue follow up goes out in the 9am window once waiting again');
eq(env.log.sends[n1].to, 'cmorgan@riverbend.co.uk', 'Riverbend follow up recipient');
ok(/"Sam Jones" <sam.jones@example.org>/.test(env.log.sends[n1].from), 'from Sam');

// --- separate thread reply is detected
env.addMessage({ labels: ['INBOX'], date: Date.parse('2026-11-24T12:00:00Z'), from: 'Casey <cmorgan@riverbend.co.uk>', to: 'oursociety@gmail.com', subject: 'Quick question' });
env.at('2026-11-25T07:30:00Z');
env.run('dailySync');
ok(/Reply received 24\/11\/26 from cmorgan@riverbend.co.uk \(separate email\)/.test(cell(3, COL.LOG)), 'separate reply detected');

// --- status values: with Replied in the dropdown it is set
dropdown(tracker, ['Sent Accepted', 'Sent & Waiting', 'Replied', 'Bounced', 'Sent Rejected']);
env.run('dailySync');
eq(cell(3, COL.STATUS), 'Replied', 'status set to Replied when the dropdown has it');

// --- missed schedule is not sent late
tracker.getRange(8, 1, 1, 5).setValues([['Citadel Securities', '', '', 'campus@citadelsecurities.com', 'Alex Taylor']]);
tracker.getRange(8, COL.PARAGRAPH).setValue(cell(6, COL.PARAGRAPH).replace(/Northgate/g, 'Citadel Securities'));
env.at('2026-11-25T10:00:00Z');
env.edit(tracker, 8, COL.DRAFT, 'Yes');
ok(mail.messages.get(mail.drafts.get(cell(8, COL.DRAFT_ID))).body.indexOf('Citadel Securities’ objectives') !== -1, 'possessive with s');
env.edit(tracker, 8, COL.SEND, '9am tomorrow');
env.at('2026-11-27T12:00:00Z');
const n2 = env.log.sends.length;
env.run('dispatcher');
eq(env.log.sends.length, n2, 'missed schedule not sent');
ok(/Scheduled send missed/.test(cell(8, COL.LOG)), 'missed logged');

// --- busy lock: a send choice waits in the cell and the dispatcher handles it
env.edit(tracker, 8, COL.SEND, 'Send now');
eq(env.log.sends.length, n2 + 1, 'send now works');
ok(/^Sent 27\/11\/26 \(Alex Taylor to campus@citadelsecurities.com\)/.test(cell(8, COL.LOG)), 'sent log');

// --- typing a firm that is already on the tracker is not researched again
tracker.getRange(9, 1).setValue('northgate');
env.edit(tracker, 9, 1);
ok(/^Skipped: northgate is already in row 2 \(Sent Accepted\)/.test(cell(9, COL.RESEARCH)), 'duplicate firm skipped');
const contactsBefore = contactCalls();
env.at('2026-11-27T12:10:00Z');
env.run('dispatcher');
eq(contactCalls(), contactsBefore, 'no research spent on the duplicate');

// --- after a bounce, typing a new address unlinks the old email and allows a fresh draft
eq(cell(7, COL.STATUS), 'Bounced', 'Two Sigma bounced');
env.edit(tracker, 7, COL.EMAIL, 'grads@twosigma.com');
eq(cell(7, COL.THREAD_ID), '', 'old thread unlinked');
eq(cell(7, COL.STATUS), '', 'status cleared for the retry');
ok(/^New address after bounce 27\/11\/26: earlier email to campus@twosigma.com, alex.morgan@twosigma.com unlinked/.test(cell(7, COL.LOG)), 'unlink logged');
env.edit(tracker, 7, COL.DRAFT, 'Yes');
ok(cell(7, COL.DRAFT_ID), 'fresh draft for the new address');
eq(mail.messages.get(mail.drafts.get(cell(7, COL.DRAFT_ID))).headers.To, 'grads@twosigma.com', 'fresh draft goes to new address');

// --- weekend schedules are flagged
env.at('2026-11-27T12:20:00Z'); // Friday
env.edit(tracker, 7, COL.SEND, '9am tomorrow');
ok(/Sat 28\/11\/26 09:00 \(a weekend\)/.test(cell(7, COL.NEXT)), 'weekend flagged');

// --- optional Reply-To setting reaches the follow up headers
setting(ss, 'Reply to address (optional)', 'oursociety@gmail.com');
env.at('2026-12-04T09:01:00Z');
const n3 = env.log.sends.length;
env.run('dispatcher');
eq(env.log.sends.length, n3 + 1, 'Citadel follow up 1 sent on Friday 4 Dec');
ok(/\r\nReply-To: oursociety@gmail.com\r\n/.test(env.log.sends[n3].raw), 'reply to header');

// --- rows inserted while a follow up is being prepared: no mixing of firms
{
  const firms = [['Alpha Capital', 'team@alphacap.com', 'Alpha note'], ['Beta Trading', 'team@betatrading.com', 'Beta note']];
  const base = tracker.getLastRow() + 1;
  firms.forEach(([firm, email, note], i) => {
    const r = base + i;
    const sent = env.addMessage({ labels: ['SENT'], date: Date.parse('2026-12-01T09:00:00Z'), from: '"Alex Taylor" <alex.taylor@example.org>', to: email, subject: SUBJECT });
    tracker.getRange(r, 1, 1, 7).setValues([[firm, '', '', email, 'Alex Taylor', 'Sent 01/12/26', 'Sent & Waiting']]);
    tracker.getRange(r, COL.FU_ON).setValue(true);
    tracker.getRange(r, COL.FU_DAYS).setValue(7);
    tracker.getRange(r, COL.FU_NOTE).setValue(note);
    tracker.getRange(r, COL.THREAD_ID).setValue(sent.threadId);
    tracker.getRange(r, COL.FU_COUNT).setValue(0);
    tracker.getRange(r, COL.NEXT_AT).setValue('2026-12-08T09:00:00.000Z');
  });
  // While Alpha's Gmail lookups run, someone inserts a row above it.
  const original = env.ctx.activityElsewhere_;
  let inserted = false;
  env.ctx.activityElsewhere_ = function (a, s) {
    if (!inserted) { inserted = true; tracker._data.splice(base, 0, []); }
    return original(a, s);
  };
  env.at('2026-12-08T09:02:00Z');
  const before = env.log.sends.length;
  env.run('dispatcher');
  env.ctx.activityElsewhere_ = original;
  const fus = env.log.sends.slice(before).filter(x => x.kind === 'followup');
  fus.forEach(x => {
    const html = htmlOf(x.raw);
    const forAlpha = x.to === 'team@alphacap.com';
    ok(forAlpha ? (html.includes('Alpha Capital') && html.includes('Alpha note') && !html.includes('Beta')) :
      (html.includes('Beta Trading') && html.includes('Beta note') && !html.includes('Alpha')), 'no mixing for ' + x.to);
  });
  ok(fus.length >= 1, 'follow ups still sent after rows moved (' + fus.length + ')');
  env.at('2026-12-08T09:12:00Z');
  env.run('dispatcher');
  const all = env.log.sends.slice(before).filter(x => x.kind === 'followup');
  eq(all.map(x => x.to).sort(), ['team@alphacap.com', 'team@betatrading.com'], 'each firm followed up exactly once');
  eq(cell(base + 1, COL.FU_NOTE), '', 'Alpha note cleared on Alpha row');
  eq(cell(base + 1, 1), 'Alpha Capital', 'Alpha moved down one row');
  ok(/note: Alpha note/.test(cell(base + 1, COL.LOG)), 'Alpha log on Alpha row');
  ok(/note: Beta note/.test(cell(base + 2, COL.LOG)), 'Beta log on Beta row');
}
if (env.log.errors && env.log.errors.length) { console.log('Logged errors:\n' + env.log.errors.join('\n')); process.exitCode = 1; }

// --- an install left behind under another account switches itself off
{
  const env3 = makeEnv({ fetch: free, me: 'old.owner@gmail.com', props: { OWNER_EMAIL: 'oursociety@gmail.com' } });
  env3.ss._sheets.push(env3.makeSheet('T', [['Firm Name']]));
  env3.ctx.ScriptApp.newTrigger('dispatcher').timeBased().everyMinutes(10).create();
  env3.ctx.ScriptApp.newTrigger('handleEdit').forSpreadsheet(env3.ss).onEdit().create();
  eq(env3.triggers.length, 2, 'old triggers exist');
  env3.run('dispatcher');
  eq(env3.triggers.length, 0, 'old account triggers removed themselves');
  eq(env3.log.sends.length, 0, 'nothing sent by the old account');
}

// --- non owner cannot run Gmail menu actions
{
  const env2 = makeEnv({ fetch: free, me: 'someone@gmail.com', props: { OWNER_EMAIL: 'oursociety@gmail.com' } });
  env2.ss._sheets.push(env2.makeSheet('T', [['Firm Name']]));
  env2.run('menuSyncNow');
  ok(env2.log.alerts.some(a => /signed in as oursociety@gmail.com/.test(a)), 'owner check');
}

// --- the Gmail service switched off: the menu says how to fix it instead of doing nothing
{
  const env4 = makeEnv({ fetch: free, noGmail: true, props: { OWNER_EMAIL: 'oursociety@gmail.com' } });
  env4.ss._sheets.push(env4.makeSheet('T', [['Firm Name']]));
  env4.run('menuSyncNow');
  ok(env4.log.alerts.some(a => /Gmail service is switched off/.test(a)), 'Gmail service check');
}

// ===================== 3. Drafting status and the menu summaries (their real dropdown) =====================
(function draftingStatus() {
  const e = makeEnv({ fetch: free, driveId: DRIVE_ID, start: '2026-10-27T10:00:00Z' });
  const para = 'Given Kestrel’s strength in systematic trading, we believe there is a strong alignment with the interests of our members. We were particularly interested in its research. This aligns with our members and we would be very interested in exploring a partnership with Kestrel.';
  const t = e.makeSheet('Sponsorship Tracker', [HEADERS,
    ['Kestrel Capital', '', '', 'campus@kestrel.com', 'Alex Taylor', '', '', ''],
    ['Hand Sent Capital', '', '', 'team@handsent.com', 'Alex Taylor', '', 'Drafting', ''],
    ['Waiting Fund', '', '', 'grads@waitingfund.com', 'Alex Taylor', '', '', '']]);
  dropdown(t, ['Sent Rejected', 'Sent Accepted', 'Drafting', 'Sent & Waiting']);
  e.ss._sheets.push(t);
  e.ss._active = t;
  const C = e.ctx.__COL;
  const v = (r, c) => t.getRange(r, c).getValue();
  e.run('setupOutreach');
  setting(e.ss, 'Prospectus (Google Drive link)', DRIVE_LINK);
  t.getRange(2, C.PARAGRAPH).setValue(para);
  t.getRange(4, C.PARAGRAPH).setValue(para.replace(/Kestrel/g, 'Waiting Fund'));

  e.edit(t, 2, C.DRAFT, 'Yes');
  eq(v(2, C.STATUS), 'Drafting', 'status becomes Drafting when the draft is made');
  e.edit(t, 2, C.SEND, 'Send now');
  eq(v(2, C.STATUS), 'Sent & Waiting', 'and Sent & Waiting when it is sent');

  // An email sent by hand for a row marked Drafting is found by Sync with Gmail now.
  e.addMessage({ labels: ['SENT'], date: Date.parse('2026-10-27T10:05:00Z'), from: '"Alex Taylor" <alex.taylor@example.org>', to: 'team@handsent.com', subject: SUBJECT });
  e.run('menuSyncNow');
  const sync = e.log.alerts[e.log.alerts.length - 1];
  ok(/^Sync with Gmail :: Gmail sync finished\. Rows checked: 3\./.test(sync), 'sync summary says how many rows were checked (' + sync.slice(0, 80) + ')');
  ok(/Row 3 \(Hand Sent Capital\): Sent 27\/10\/26 \(found in Gmail and linked\)/.test(sync), 'sync summary lists what changed');
  eq(v(3, C.STATUS), 'Sent & Waiting', 'Drafting changes to Sent & Waiting for an email sent by hand');
  e.run('menuSyncNow');
  ok(/Nothing new in Gmail for those rows/.test(e.log.alerts[e.log.alerts.length - 1]), 'second sync says nothing is new');

  // Process due sends with nothing due explains what is coming up and what is waiting.
  e.edit(t, 4, C.DRAFT, 'Yes');
  eq(v(4, C.STATUS), 'Drafting', 'second row drafted');
  e.run('menuProcessNow');
  const proc = e.log.alerts[e.log.alerts.length - 1];
  ok(/Nothing was due right now/.test(proc), 'nothing due');
  ok(/Coming up:\nRow 2 \(Kestrel Capital\): Follow up 1 of 2 due Tue 03\/11\/26 09:00/.test(proc), 'coming up lists the follow up');
  ok(/Drafts waiting for you to choose Send now, 9am tomorrow or 9am Monday in the Send column \(J\):\nRow 4 \(Waiting Fund\)/.test(proc), 'waiting drafts listed');
  ok(/Follow ups only go out between 9am and 10am UK time on weekdays/.test(proc), 'follow up hour explained');
  e.edit(t, 4, C.SEND, '9am tomorrow');
  e.at('2026-10-28T09:03:00Z');
  e.run('menuProcessNow');
  const done = e.log.alerts[e.log.alerts.length - 1];
  ok(/Done\. What changed:\nRow 4 \(Waiting Fund\): Sent 28\/10\/26 \(Alex Taylor to grads@waitingfund\.com\)/.test(done), 'process summary lists the send');
  eq(v(4, C.STATUS), 'Sent & Waiting', 'scheduled send changes Drafting to Sent & Waiting');
  eq(e.log.sends.length, 2, 'two emails sent in this run');
  // Another run holding the lock: the summary says so instead of claiming nothing was due.
  const lock = e.ctx.LockService.getScriptLock();
  lock.tryLock(1000);
  e.run('menuProcessNow');
  lock.releaseLock();
  ok(/Another run of the script was busy/.test(e.log.alerts[e.log.alerts.length - 1]), 'busy run explained');
  if (e.log.errors && e.log.errors.length) { console.log('Drafting scenario logged errors:\n' + e.log.errors.join('\n')); process.exitCode = 1; }
})();

// ===================== 4. Settings tab from an older version =====================
(function settingsUpgrade() {
  const e = makeEnv({ fetch: free, props: { CLAUDE_API_KEY: 'sk-ant-old' } });
  e.ss._sheets.push(e.makeSheet('Tracker', [HEADERS]));
  e.ss._sheets.push(e.makeSheet('Outreach Settings', [['Setting', 'Value', 'Notes'],
    ['Prospectus (Google Drive link)', DRIVE_LINK, 'old note'],
    ['Maximum follow ups', '2', 'Counts follow ups sent by hand too.'],
    ['Claude model', 'claude-sonnet-5-5', ''],
    ['Web searches for contacts', '6', 'Each search costs about 1 US cent plus tokens.'],
    ['Web searches for paragraph', '4', ''],
    ['Research engine', 'Free', 'Free: Tavily web search plus a Groq model.']]));
  e.run('setupOutreach');
  const sh = e.ss.getSheetByName('Outreach Settings');
  const rows = sh.getRange(2, 1, sh.getLastRow() - 1, 3).getValues();
  const labelsNow = rows.map(r => r[0]);
  ok(!labelsNow.includes('Claude model') && !labelsNow.includes('Research engine'), 'old Claude rows removed');
  eq(setting(e.ss, 'Web searches for contacts'), '6', 'values kept');
  eq(rows.find(r => r[0] === 'Web searches for contacts')[2], '1 to 5. Each one uses one of the 1,000 free Tavily searches a month.', 'notes refreshed');
  eq(setting(e.ss, 'Prospectus (Google Drive link)'), DRIVE_LINK, 'prospectus kept');
  ok(labelsNow.includes('Most email addresses per firm') && labelsNow.includes('Free model for contacts (Groq)'), 'new settings added');
  ok(!e.props.has('CLAUDE_API_KEY'), 'old Claude key removed');
  const st = e.run('settings_');
  ok(st.contactSearches === 5 && st.paragraphSearches === 3, 'search counts capped at what the free engine uses');
})();

// ===================== 5. Free research engine (Tavily search plus Groq model) =====================
(function freeEngine() {
  calls.tavily.length = 0;
  calls.groq.length = 0;
  const e = makeEnv({ fetch: free, driveId: DRIVE_ID, start: '2026-10-27T10:00:00Z' });
  const t = e.makeSheet('Sponsorship Tracker', [HEADERS]);
  e.ss._sheets.push(t);
  e.ss._active = t;
  const C = e.ctx.__COL;
  const v = (r, c) => t.getRange(r, c).getValue();
  e.run('setupOutreach');

  // Without keys nothing runs and the menu says what is missing.
  t.getRange(2, 1).setValue('Acme Capital');
  e.edit(t, 2, 1);
  eq(v(2, C.RESEARCH), 'Queued for research', 'free: queued');
  e.at('2026-10-27T10:10:00Z');
  e.run('dispatcher');
  eq(calls.tavily.length + calls.groq.length, 0, 'free: nothing runs without keys');
  e.run('menuResearchNow');
  ok(e.log.alerts.some(a => /Set the Tavily key and Groq key first/.test(a)), 'free: menu asks for both keys');

  // With keys: research checks the model's answer against the pages.
  Object.keys(KEYS).forEach(k => e.props.set(k, KEYS[k]));
  groqMode['Acme Capital:paragraph'] = 'minute-once';
  e.at('2026-10-27T10:20:00Z');
  e.run('dispatcher');
  const notes = String(v(2, C.RESEARCH));
  eq(v(2, C.EMAIL), 'campus-emea@acmecapital.com, p.shah@acmecapital.com, sarah.khan@acmecapital.com', 'free: every relevant address, published ones first');
  eq(v(2, C.CONTACT), 'Priya Shah, Sarah Khan', 'free: names of the people emailed');
  eq(v(2, C.ROLE), 'Graduate Recruitment Lead, EMEA; Head of Early Careers EMEA', 'free: their roles, without dashes');
  ok(/^Researched 27\/10\/26\nDomain: acmecapital\.com \| Email format: \{first\}\.\{last\}@acmecapital\.com/.test(notes), 'free: notes header');
  ok(/p\.shah@acmecapital\.com \| Priya Shah \| Graduate Recruitment Lead, EMEA \| published/.test(notes), 'free: published person kept with name');
  ok(/sarah\.khan@acmecapital\.com \| Sarah Khan \| Head of Early Careers EMEA \| pattern_guess \| EMEA \| medium \| https:\/\/uk\.linkedin\.com\/in\/sarahkhan/.test(notes), 'free: guess rebuilt from the format, confidence lowered');
  ok(/• media@acmecapital\.com \| Media mailbox \| role_mailbox/.test(notes) && !/Recommended: [^\n]*media@/.test(notes), 'free: press mailbox listed but never emailed');
  ok(!/skhan@/.test(notes), 'free: guess in the wrong format replaced');
  ok(/Not used [^\n]*: tom\.invented@acmecapital\.com, recruiting@acmecapital\.com, careers@brightnetwork\.co\.uk/.test(notes), 'free: invented, unseen and third party addresses dropped');
  ok(!/• [^\n]*(tom\.invented|recruiting@|brightnetwork)/.test(notes), 'free: dropped addresses not listed as contacts');
  ok(/Why: Campus mailbox is published, Sarah runs early careers\./.test(notes), 'free: dash removed from the reasons');
  ok(/^Given Acme Capital’s strength in quantitative research, and technology/.test(v(2, C.PARAGRAPH)), 'free: paragraph written and tidied');
  ok(/Paragraph sources: https:\/\/news\.example\/acme-lab https:\/\/www\.acmecapital\.com\/engineering$/m.test(notes), 'free: sources mapped from numbers, made up links dropped');
  eq(calls.tavily.length, 5, 'free: 3 contact searches and 2 paragraph searches');
  ok(calls.tavily.slice(0, 3).every(b => b.include_raw_content === true), 'free: full pages fetched for contacts');
  eq(calls.groq.map(g => (g.contacts ? 'c' : 'p')).join(''), 'cpp', 'free: per minute limit waited out and retried');
  ok((e.log.sleeps || []).some(ms => ms >= 2000 && ms <= 3000), 'free: waited as long as retry-after said');
  ok(/Check email and paragraph/.test(v(2, C.NEXT)), 'free: next step');

  // Daily model limit: the row waits and finishes by itself, reusing the searches already made.
  groqMode['Zeta Partners:contacts'] = 'daily';
  t.getRange(3, 1).setValue('Zeta Partners');
  e.edit(t, 3, 1);
  e.at('2026-10-27T10:30:00Z');
  const tv1 = calls.tavily.length, gq1 = calls.groq.length;
  e.run('dispatcher');
  ok(/^Queued for research \(free limit reached, retrying automatically\) 27\/10\/26/.test(v(3, C.RESEARCH)), 'free: daily limit queues the row again');
  ok(/free Groq limit is used up/.test(v(3, C.RESEARCH)), 'free: reason noted');
  ok(/^Research paused 27\/10\/26: free limit reached, it retries automatically/.test(v(3, C.LOG)), 'free: pause logged');
  eq(v(3, C.NEXT), 'Waiting for the free research limit to reset', 'free: next step while paused');
  eq(calls.groq.length - gq1, 1, 'free: no paragraph attempt once the limit is hit');
  eq(calls.tavily.length - tv1, 3, 'free: only the contact searches ran');
  eq(new Date(Number(e.props.get('RESEARCH_PAUSE_UNTIL'))).toISOString(), '2026-10-27T11:30:00.000Z', 'free: paused for an hour');
  e.run('menuCheckSetup');
  const check = e.log.alerts[e.log.alerts.length - 1];
  ok(/OK  Tavily key set/.test(check) && /OK  Groq key works/.test(check) && /TIP Research is paused until/.test(check), 'free: setup check');
  ok(!/Claude/.test(check), 'free: no Claude in the setup check');
  e.at('2026-10-27T10:50:00Z');
  e.run('dispatcher');
  eq(calls.groq.length - gq1, 1, 'free: nothing runs during the pause');
  delete groqMode['Zeta Partners:contacts'];
  e.at('2026-10-27T11:40:00Z');
  const tv2 = calls.tavily.length;
  e.run('dispatcher');
  eq(v(3, C.EMAIL), 'grads@zetapartners.com', 'free: finished automatically after the pause');
  ok(/^Researched 27\/10\/26\nDomain: zetapartners\.com/.test(v(3, C.RESEARCH)), 'free: researched after the pause, old problems gone');
  eq(calls.tavily.length - tv2, 2, 'free: contact searches reused from the cache');

  // Broken JSON from the model: it is asked once more.
  groqMode['Kappa Trading:contacts'] = 'nojson-once';
  t.getRange(5, 1).setValue('Kappa Trading');
  e.edit(t, 5, 1);
  e.at('2026-10-27T11:45:00Z');
  const gq3 = calls.groq.length;
  e.run('dispatcher');
  eq(v(5, C.EMAIL), 'careers@kappatrading.com', 'free: broken JSON retried once');
  eq(calls.groq.length - gq3, 3, 'free: two contact calls and one paragraph call');

  // Monthly search limit: research pauses for a day.
  t.getRange(6, 1).setValue('Omega Quant');
  e.edit(t, 6, 1);
  e.at('2026-10-27T11:50:00Z');
  e.run('dispatcher');
  ok(/^Queued for research \(free limit reached/.test(v(6, C.RESEARCH)) && /Tavily searches for this month are used up/.test(v(6, C.RESEARCH)), 'free: monthly search limit pauses research');
  eq(new Date(Number(e.props.get('RESEARCH_PAUSE_UNTIL'))).toISOString(), '2026-10-28T11:50:00.000Z', 'free: paused for a day');
  if (e.log.errors && e.log.errors.length) { console.log('Free engine logged errors:\n' + e.log.errors.join('\n')); process.exitCode = 1; }
})();

console.log('All ' + passed + ' checks passed. Gmail searches made: ' + env.log.searches);
