// Minimal Apps Script mocks: Sheets, Gmail (GmailApp and the Gmail API), Drive, UrlFetch, clock.
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function makeEnv(opts) {
  opts = opts || {};
  const clock = { now: Date.parse(opts.start || '2026-10-27T10:00:00Z') };
  const log = { alerts: [], toasts: [], fetches: [], sends: [] };

  // ---------- time formatting in Europe/London ----------
  const dowMap = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };
  function londonParts(ms) {
    const dtf = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit',
      minute: '2-digit', second: '2-digit', weekday: 'short', hourCycle: 'h23'
    });
    const o = {};
    dtf.formatToParts(new Date(ms)).forEach(p => { o[p.type] = p.value; });
    return o;
  }
  function formatDate(date, tz, pattern) {
    if (tz !== 'Europe/London') throw new Error('unexpected tz ' + tz);
    const ms = date.getTime();
    const p = londonParts(ms);
    const off = (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - Math.floor(ms / 1000) * 1000) / 60000;
    const abs = Math.abs(off);
    const Z = (off >= 0 ? '+' : '-') + String(Math.floor(abs / 60)).padStart(2, '0') + String(abs % 60).padStart(2, '0');
    return pattern.replace(/yyyy|yy|MM|dd|HH|mm|EEE|u|Z/g, t => ({
      yyyy: p.year, yy: p.year.slice(-2), MM: p.month, dd: p.day, HH: p.hour, mm: p.minute,
      EEE: p.weekday, u: String(dowMap[p.weekday]), Z: Z
    })[t]);
  }

  // ---------- Sheets ----------
  let sheetIdSeq = 100;
  function makeSheet(name, rows) {
    const data = []; // data[r][c] 1-based
    const formats = {};
    const validations = {};
    const sheet = {
      _data: data, _validations: validations, _hidden: [],
      _id: sheetIdSeq++, _name: name, _maxRows: 1000,
      getSheetId() { return this._id; },
      getName() { return this._name; },
      getMaxRows() { return this._maxRows; },
      getLastRow() {
        for (let r = data.length - 1; r >= 1; r--) {
          const row = data[r];
          if (row && row.some(v => v !== '' && v !== null && v !== undefined)) return r;
        }
        return 0;
      },
      _get(r, c) { return (data[r] && data[r][c] !== undefined) ? data[r][c] : ''; },
      _set(r, c, v) {
        if (!data[r]) data[r] = [];
        if (formats[r + ',' + c] === '@' && v !== '' && v !== null && typeof v !== 'string' && typeof v !== 'boolean') v = String(v);
        data[r][c] = v;
      },
      getRange(a, b, nr, nc) {
        if (typeof a === 'string') {
          const m = a.match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
          const col = s => s.split('').reduce((acc, ch) => acc * 26 + ch.charCodeAt(0) - 64, 0);
          return makeRange(sheet, +m[2], col(m[1]), +m[4] - +m[2] + 1, col(m[3]) - col(m[1]) + 1);
        }
        return makeRange(sheet, a, b, nr || 1, nc || 1);
      },
      hideColumns(c, n) { this._hidden.push([c, n]); },
      deleteRow(r) { data.splice(r, 1); return this; },
      setColumnWidth() { return this; },
      setFrozenRows() { return this; }
    };
    function makeRange(sh, r, c, nr, nc) {
      return {
        getSheet() { return sh; },
        getRow() { return r; }, getLastRow() { return r + nr - 1; },
        getColumn() { return c; }, getLastColumn() { return c + nc - 1; },
        getValues() { const out = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push(sh._get(r + i, c + j)); out.push(row); } return out; },
        getValue() { return sh._get(r, c); },
        setValues(vals) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) sh._set(r + i, c + j, vals[i][j]); return this; },
        setValue(v) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) sh._set(r + i, c + j, v); return this; },
        setNumberFormat(f) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) formats[(r + i) + ',' + (c + j)] = f; return this; },
        setDataValidation(rule) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) validations[(r + i) + ',' + (c + j)] = rule; return this; },
        getDataValidation() { return validations[r + ',' + c] || null; },
        setWrapStrategy() { return this; },
        setFontWeight() { return this; },
        copyFormatToRange() { return this; }
      };
    }
    (rows || []).forEach((row, i) => row.forEach((v, j) => sheet._set(i + 1, j + 1, v)));
    return sheet;
  }

  const ss = {
    _sheets: [], _active: null,
    getId() { return 'SPREADSHEET1'; },
    getSheets() { return this._sheets.slice(); },
    getSheetByName(n) { return this._sheets.find(s => s.getName() === n) || null; },
    insertSheet(n) { const s = makeSheet(n, []); this._sheets.push(s); return s; },
    getActiveSheet() { return this._active || this._sheets[0]; },
    toast(m) { log.toasts.push(m); }
  };

  const Criteria = { VALUE_IN_LIST: 'VALUE_IN_LIST', VALUE_IN_RANGE: 'VALUE_IN_RANGE', CHECKBOX: 'CHECKBOX', NUMBER_BETWEEN: 'NUMBER_BETWEEN' };
  function dvBuilder() {
    const rule = { type: null, values: [], allowInvalid: true };
    const b = {
      requireValueInList(v, show) { rule.type = Criteria.VALUE_IN_LIST; rule.values = [v, show]; return b; },
      requireValueInRange(rg, show) { rule.type = Criteria.VALUE_IN_RANGE; rule.values = [rg, show]; return b; },
      requireCheckbox() { rule.type = Criteria.CHECKBOX; return b; },
      requireNumberBetween(a, z) { rule.type = Criteria.NUMBER_BETWEEN; rule.values = [a, z]; return b; },
      setAllowInvalid(x) { rule.allowInvalid = x; return b; },
      build() { return { getCriteriaType: () => rule.type, getCriteriaValues: () => rule.values, _rule: rule }; }
    };
    return b;
  }
  let activeRange = null;
  const ui = {
    ButtonSet: { OK: 'OK', YES_NO: 'YES_NO', OK_CANCEL: 'OK_CANCEL' },
    Button: { OK: 'OK', YES: 'YES', NO: 'NO', CANCEL: 'CANCEL' },
    alert(title, msg) { log.alerts.push(title + ' :: ' + (msg || '')); return 'YES'; },
    prompt() { return { getSelectedButton: () => 'OK', getResponseText: () => opts.promptText || '' }; },
    createMenu() { const m = { addItem() { return m; }, addSeparator() { return m; }, addToUi() { return m; } }; return m; }
  };
  const SpreadsheetApp = {
    getActiveSpreadsheet: () => ss,
    openById: () => ss,
    flush: () => {},
    getUi: () => ui,
    newDataValidation: dvBuilder,
    DataValidationCriteria: Criteria,
    WrapStrategy: { CLIP: 'CLIP', WRAP: 'WRAP' },
    getActiveRange: () => activeRange
  };

  // ---------- Gmail mailbox ----------
  const ME = 'oursociety@gmail.com';
  const ALIASES = ['jordan.lee@example.org', 'alex.taylor@example.org', 'sam.jones@example.org'];
  const mail = { threads: new Map(), messages: new Map(), drafts: new Map(), seq: 1 };
  function newId() { return (0x18f0000000000000 + mail.seq++ * 7919).toString(16); }
  function normSubject(s) { return String(s || '').replace(/^((re|fwd?|aw)\s*:\s*)+/i, '').trim().toLowerCase(); }

  function addMessage(o) {
    const id = newId();
    let threadId = o.threadId;
    if (!threadId || !mail.threads.has(threadId)) { threadId = threadId || newId(); mail.threads.set(threadId, { id: threadId, ids: [] }); }
    const headers = Object.assign({
      From: o.from, To: o.to || '', Subject: o.subject || '',
      'Message-ID': o.messageId === undefined ? '<' + id + '@mail.example.com>' : o.messageId
    }, o.cc ? { Cc: o.cc } : {}, o.headers || {});
    if (o.messageId === null) delete headers['Message-ID'];
    const msg = { id, threadId, labelIds: o.labels || ['INBOX'], internalDate: o.date || clock.now, headers, body: o.body || '', attachments: o.attachments || [] };
    if (o.snippet !== undefined) msg.snippet = o.snippet;
    mail.messages.set(id, msg);
    mail.threads.get(threadId).ids.push(id);
    return msg;
  }

  function msgWrapper(id) {
    const m = () => mail.messages.get(id);
    return {
      getId: () => id,
      getTo: () => m().headers.To || '', getCc: () => m().headers.Cc || '', getBcc: () => m().headers.Bcc || '',
      getFrom: () => m().headers.From, getSubject: () => m().headers.Subject, getBody: () => m().body,
      getAttachments: () => m().attachments, getThread: () => ({ getId: () => m().threadId })
    };
  }
  function draftWrapper(draftId) {
    return {
      getId: () => draftId,
      getMessage: () => msgWrapper(mail.drafts.get(draftId)),
      update(to, subject, body, o) {
        const msg = mail.messages.get(mail.drafts.get(draftId));
        if (o.from && o.from !== ME && ALIASES.indexOf(o.from) === -1) throw new Error('Invalid argument: from');
        msg.headers.From = '"' + o.name + '" <' + o.from + '>';
        msg.headers.To = to; msg.headers.Subject = subject; msg.body = o.htmlBody; msg.attachments = o.attachments || [];
        return draftWrapper(draftId);
      },
      send() {
        const msgId = mail.drafts.get(draftId);
        const msg = mail.messages.get(msgId);
        msg.labelIds = ['SENT'];
        msg.internalDate = clock.now;
        msg.headers['Message-ID'] = '<sent-' + msgId + '@mail.gmail.com>';
        mail.drafts.delete(draftId);
        log.sends.push({ kind: 'initial', to: msg.headers.To, from: msg.headers.From, subject: msg.headers.Subject, at: clock.now });
        return msgWrapper(msgId);
      }
    };
  }
  const GmailApp = {
    getAliases: () => ALIASES.slice(),
    createDraft(to, subject, body, o) {
      if (o.from && o.from !== ME && ALIASES.indexOf(o.from) === -1) throw new Error('Invalid argument: from');
      const msg = addMessage({ labels: ['DRAFT'], from: '"' + o.name + '" <' + o.from + '>', to, subject, body: o.htmlBody, attachments: o.attachments || [] });
      const draftId = 'r-' + (5000000000000000000 + mail.seq++);
      mail.drafts.set(draftId, msg.id);
      return draftWrapper(draftId);
    },
    getDraft(id) { if (!mail.drafts.has(id)) throw new Error('Invalid argument: draftId'); return draftWrapper(id); }
  };

  function metaOf(msg, headerNames) {
    const wanted = (headerNames || []).map(h => h.toLowerCase());
    const headers = Object.keys(msg.headers).filter(k => !wanted.length || wanted.indexOf(k.toLowerCase()) !== -1)
      .map(k => ({ name: k, value: msg.headers[k] }));
    const snippet = msg.snippet !== undefined ? msg.snippet : String(msg.body || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
    return { id: msg.id, threadId: msg.threadId, labelIds: msg.labelIds.slice(), internalDate: String(msg.internalDate), snippet, payload: { headers } };
  }

  // Gmail search: supports in:, -in:, to:, cc:, bcc:, from:, after:, newer_than:, {OR groups}, "quoted" and words.
  function tokenize(q) {
    const out = []; let i = 0;
    while (i < q.length) {
      if (q[i] === ' ') { i++; continue; }
      if (q[i] === '{') { const j = q.indexOf('}', i); out.push({ group: tokenize(q.slice(i + 1, j)) }); i = j + 1; continue; }
      let j = i, inQ = false;
      while (j < q.length && (inQ || (q[j] !== ' ' && q[j] !== '{'))) { if (q[j] === '"') inQ = !inQ; j++; }
      out.push({ term: q.slice(i, j) }); i = j;
    }
    return out;
  }
  function termMatches(t, msg) {
    let neg = false; let s = t;
    if (s[0] === '-') { neg = true; s = s.slice(1); }
    const all = (Object.values(msg.headers).join(' ') + ' ' + msg.body).toLowerCase();
    let ok;
    const m = s.match(/^([a-z_]+):(.*)$/i);
    if (m && !/^"/.test(s)) {
      const op = m[1].toLowerCase(), v = m[2].replace(/"/g, '').toLowerCase();
      if (op === 'in') ok = (v === 'sent' && msg.labelIds.includes('SENT')) || (v === 'drafts' && msg.labelIds.includes('DRAFT')) || (v === 'trash' && msg.labelIds.includes('TRASH'));
      else if (op === 'to') ok = String(msg.headers.To || '').toLowerCase().includes(v);
      else if (op === 'cc') ok = String(msg.headers.Cc || '').toLowerCase().includes(v);
      else if (op === 'bcc') ok = String(msg.headers.Bcc || '').toLowerCase().includes(v);
      else if (op === 'from') ok = String(msg.headers.From || '').toLowerCase().includes(v);
      else if (op === 'after') { const [y, mo, d] = v.split('/').map(Number); ok = msg.internalDate >= Date.UTC(y, mo - 1, d); }
      else if (op === 'newer_than') ok = true;
      else ok = all.includes(s.toLowerCase());
    } else ok = all.includes(s.replace(/"/g, '').toLowerCase());
    return neg ? !ok : ok;
  }
  function matches(tokens, msg) {
    return tokens.every(t => t.group ? t.group.some(g => termMatches(g.term, msg)) : termMatches(t.term, msg));
  }
  function search(q) {
    const tokens = tokenize(q);
    const hits = [...mail.messages.values()].filter(m => !m.labelIds.includes('DRAFT') || /in:drafts/.test(q)).filter(m => matches(tokens, m));
    hits.sort((a, b) => b.internalDate - a.internalDate);
    log.searches = (log.searches || 0) + 1;
    return hits;
  }

  const Gmail = {
    Users: {
      Threads: {
        get(user, id, o) {
          const t = mail.threads.get(id);
          if (!t) throw new Error('API call to gmail.users.threads.get failed with error: Requested entity was not found.');
          return { id, messages: t.ids.map(mid => mail.messages.get(mid)).sort((a, b) => a.internalDate - b.internalDate).map(m => metaOf(m, o && o.metadataHeaders)) };
        },
        list(user, o) {
          const ids = []; search(o.q).forEach(m => { if (ids.indexOf(m.threadId) === -1) ids.push(m.threadId); });
          return ids.length ? { threads: ids.slice(0, o.maxResults || 100).map(id => ({ id })) } : {};
        }
      },
      Messages: {
        list(user, o) { const hits = search(o.q).slice(0, o.maxResults || 100); return hits.length ? { messages: hits.map(m => ({ id: m.id, threadId: m.threadId })) } : {}; },
        get(user, id, o) { return metaOf(mail.messages.get(id), o && o.metadataHeaders); },
        send(resource, user) {
          const raw = Buffer.from(resource.raw.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
          const [head] = raw.split('\r\n\r\n');
          const headers = {};
          head.split('\r\n').forEach(line => { const i = line.indexOf(':'); headers[line.slice(0, i)] = line.slice(i + 1).trim(); });
          const fromAddr = (headers.From.match(/<([^>]+)>/) || [])[1];
          if (fromAddr !== ME && ALIASES.indexOf(fromAddr) === -1) throw new Error('bad from ' + fromAddr);
          let threadId = resource.threadId;
          const t = threadId && mail.threads.get(threadId);
          const firstSubject = t ? mail.messages.get(t.ids[0]).headers.Subject : '';
          if (!t || normSubject(firstSubject) !== normSubject(headers.Subject) || !headers['In-Reply-To']) threadId = null;
          const msg = addMessage({ threadId: threadId || undefined, labels: ['SENT'], from: headers.From, to: headers.To, subject: headers.Subject,
            headers: { 'In-Reply-To': headers['In-Reply-To'], References: headers.References }, body: raw });
          log.sends.push({ kind: 'followup', to: headers.To, from: headers.From, subject: headers.Subject, inReplyTo: headers['In-Reply-To'], references: headers.References, threadId: msg.threadId, raw, at: clock.now });
          return { id: msg.id, threadId: msg.threadId, labelIds: ['SENT'] };
        }
      }
    }
  };

  // ---------- Other services ----------
  const props = new Map(Object.entries(opts.props || {}));
  const PropertiesService = { getScriptProperties: () => ({
    getProperty: k => (props.has(k) ? props.get(k) : null), setProperty: (k, v) => { props.set(k, String(v)); }, deleteProperty: k => { props.delete(k); }
  }) };
  const cache = new Map();
  const CacheService = { getScriptCache: () => ({ get: k => (cache.has(k) ? cache.get(k) : null), put: (k, v) => { cache.set(k, v); }, remove: k => { cache.delete(k); } }) };
  let lockHeld = false;
  const LockService = { getScriptLock: () => ({
    tryLock: () => { if (lockHeld && !opts.reentrantLock) return false; lockHeld = true; return true; },
    releaseLock: () => { lockHeld = false; }
  }) };
  const dir = path.join(__dirname, '..');
  const HtmlService = { createTemplateFromFile: name => ({ getRawContent: () => fs.readFileSync(path.join(dir, name + '.html'), 'utf8') }) };
  const blob = { getName: () => 'Sponsorship Prospectus 2026-27.pdf', getBytes: () => Buffer.alloc(2048), setName() { return blob; } };
  const DriveApp = { getFileById: id => { if (id !== opts.driveId) throw new Error('No item with the given ID could be found'); return { getMimeType: () => 'application/pdf', getBlob: () => blob, getName: () => blob.getName() }; } };
  const MimeType = { GOOGLE_DOCS: 'application/vnd.google-apps.document', GOOGLE_SLIDES: 'application/vnd.google-apps.presentation', PDF: 'application/pdf' };
  const triggers = [];
  const ScriptApp = {
    getProjectTriggers: () => triggers.slice(),
    deleteTrigger: t => { triggers.splice(triggers.indexOf(t), 1); },
    newTrigger(fn) {
      const t = { fn, getHandlerFunction: () => fn, spec: [] };
      const b = new Proxy({}, { get: (o, k) => (k === 'create' ? () => { triggers.push(t); return t; } : (...a) => { t.spec.push(k + '(' + a.join(',') + ')'); return b; }) });
      return b;
    }
  };
  let uuid = 0;
  const Utilities = {
    formatDate,
    base64Encode: s => Buffer.from(String(s), 'utf8').toString('base64'),
    base64EncodeWebSafe: s => (Array.isArray(s) ? Buffer.from(s.map(b => b & 255)) : Buffer.from(String(s), 'utf8'))
      .toString('base64').replace(/\+/g, '-').replace(/\//g, '_'),
    computeDigest: (alg, s) => {
      if (alg !== 'MD5') throw new Error('unexpected digest ' + alg);
      return Array.from(require('crypto').createHash('md5').update(String(s), 'utf8').digest()).map(b => (b > 127 ? b - 256 : b));
    },
    DigestAlgorithm: { MD5: 'MD5' },
    getUuid: () => '00000000-0000-0000-0000-' + String(++uuid).padStart(12, '0'),
    sleep: ms => { log.sleeps = (log.sleeps || []).concat([ms]); clock.now += ms; },
    Charset: { UTF_8: 'UTF_8' }
  };
  const Session = { getEffectiveUser: () => ({ getEmail: () => opts.me || ME }) };
  const UrlFetchApp = { fetch(url, o) { log.fetches.push({ url, o }); return opts.fetch(url, o, log); } };

  const globals = {
    console: { log() {}, error: (...a) => { log.errors = (log.errors || []).concat([a.join(' ')]); } },
    SpreadsheetApp, GmailApp, Gmail, PropertiesService, CacheService, LockService, HtmlService, DriveApp,
    MimeType, ScriptApp, Utilities, Session, UrlFetchApp, __clock: clock
  };
  if (opts.noGmail) delete globals.Gmail; // the Gmail advanced service switched off
  const ctx = vm.createContext(globals);
  vm.runInContext(`
    const __RealDate = Date;
    class FakeDate extends __RealDate {
      constructor(...a) { if (a.length === 0) super(__clock.now); else super(...a); }
      static now() { return __clock.now; }
    }
    globalThis.Date = FakeDate;`, ctx);
  const code = fs.readFileSync(path.join(dir, 'Code.gs'), 'utf8');
  vm.runInContext(code + '\n;globalThis.__COL = COL; globalThis.__CACHE = CACHE;', ctx, { filename: 'Code.gs' });

  return {
    ctx, clock, log, ss, mail, props, cache, triggers, makeSheet, addMessage, ME, ALIASES,
    setActiveRange: r => { activeRange = r; },
    run(name, ...args) { for (const k of Object.keys(ctx.__CACHE)) delete ctx.__CACHE[k]; return ctx[name](...args); },
    call(name, ...args) { return ctx[name](...args); },
    at(iso) { clock.now = Date.parse(iso); },
    edit(sheet, r, c, value, nr, nc) {
      const range = sheet.getRange(r, c, nr || 1, nc || 1);
      if (value !== undefined) range.setValue(value);
      for (const k of Object.keys(ctx.__CACHE)) delete ctx.__CACHE[k];
      ctx.handleEdit({ range });
    }
  };
}

module.exports = { makeEnv };
